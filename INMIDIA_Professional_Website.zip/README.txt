INMIDIA WEBSITE PACKAGE

Files:
- index.html: homepage
- blog-*.html: three practical marketing guides
- privacy-policy.html, terms.html, disclaimer.html: starter policy pages
- robots.txt and sitemap.xml: basic crawler files

PUBLISHING TO GITHUB PAGES
1. Extract this ZIP.
2. Upload the CONTENTS of this folder into the root of the inmidia40.github.io repository (not an extra nested folder).
3. Keep index.html at repository root and commit changes.
4. Wait for GitHub Pages to publish, then test on desktop and mobile.
5. Test the Google Form submission and WhatsApp link.

IMPORTANT NOTES
- Images are loaded from Unsplash image URLs, so visitors need internet access and external image delivery must remain available.
- Replace the generic IM text mark with your official logo file if desired.
- Review the legal starter pages against your actual business practices; they are not legal advice.
- The portfolio items are clearly labeled concept campaigns, not claimed client work.
- SEO improvements do not guarantee rankings or AdSense approval. Add real, useful content over time and set up Google Search Console after launch.
